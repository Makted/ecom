#!/bin/bash
echo 'Deploying to AWS'